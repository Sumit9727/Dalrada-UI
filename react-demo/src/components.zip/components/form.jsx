import React, { Component } from "react";

const intialState = {
  username: "",
  email: "",
  password: "",
  usernameError: "",
  emailError: "",
  passwordError: ""
};

class Form extends Component {
  state = intialState;

  handleUsernameChange = event => {
    this.setState({
      username: event.target.value
    });
  };
  handleEmailChange = event => {
    this.setState({
      email: event.target.value
    });
  };
  handlePasswordChange = event => {
    this.setState({
      password: event.target.value
    });
  };
  validate = () => {
    if (!this.state.username.length > 3) {
      this.setState({
        usernameError: "username should be more than 3 characters"
      });
      alert(`username should be more than 3 characters`);
      return false;
    }
    if (!this.state.email.includes("@")) {
      this.setState({ emailError: "invalid email" });
      return false;
    }

    if (!this.state.password.length > 3) {
      this.setState({ passwordError: "weak password" });
      alert(`weak password`);
      return false;
    }

    return true;
  };

  handleSubmit = event => {
    const isValid = this.validate();
    if (isValid) {
      alert(`valid`);
      // clear form
      this.setState(intialState);
    }
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            placeholder="username"
            onChange={this.handlePasswordChange}
          ></input>
          <div>{this.state.usernameError}</div>
          <input
            type="text"
            placeholder="email"
            onChange={this.handleEmailChange}
          ></input>
          <div>{this.state.emailError}</div>
          <input
            type="password"
            placeholder="password"
            onChange={this.handlePasswordChange}
          ></input>
          <div>{this.state.passwordError}</div>
          <input type="submit" placeholder="submit" />
        </form>
      </div>
    );
  }
}

export default Form;
