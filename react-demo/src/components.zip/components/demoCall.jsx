import React, { Component } from "react";
import axios from "axios";

class Call extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  async getData() {
    axios
      .get("http://localhost:8111/dalrada/user/userResource/users")
      .then(response => {
        console.log(response.data);
      })
      .catch(error => console.log(error));
  }
  render() {
    return (
      <div className="text-center m-4 p-5">
        <button onClick={this.getData}>Click Me</button>
      </div>
    );
  }
}

export default Call;
