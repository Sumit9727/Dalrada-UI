import React, { Component } from "react";
import { Route, Link, Switch } from "react-router-dom";
import ForgotPassword from "./forgotPassword";

class Welcome extends Component {
  state = {
    count: 1
  };

  render() {
    return (
      <React.Fragment>
        <div className="sidenav">
          <div className="login-main-text">
            <h2>DALRADA</h2>
            <p>Login from here to access.</p>
          </div>
        </div>
        <div className="main">
          <div className="col-md-6 col-sm-12">
            <div className="login-form">
              <h3>Login</h3>
              <form type="submit">
                <div className="form-group">
                  <label>User Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="User Name"
                  />
                </div>
                <div className="form-group">
                  <label>Password</label>
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Password"
                  />
                </div>
                <a
                  href="dashboard.html"
                  className="btn btn-black active text-white mr-1"
                  role="button"
                  aria-pressed="true"
                >
                  Login
                </a>
                <a
                  href="register.html"
                  className="btn btn-second active text-white ml-1"
                  role="button"
                  aria-pressed="true"
                >
                  Register
                </a>
              </form>
              <br />
              <Link to="/forgotpassword">Forgot Password?</Link>
            </div>
          </div>
          <Switch>
            <Route exact path="/forgotpassword" component={ForgotPassword} />
          </Switch>
        </div>
      </React.Fragment>
    );
  }
}

export default Welcome;
