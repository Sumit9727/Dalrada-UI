import React, { Component } from "react";
import axios from "axios";
import {
  MDBContainer,
  MDBInput,
  MDBBtn,
  MDBCard,
  MDBCardHeader,
  MDBCardBody,
  MDBIcon,
  MDBModal,
  MDBModalBody,
  MDBModalHeader,
  MDBModalFooter,
  MDBDataTable,
  MDBRow,
  MDBCol,
} from "mdbreact";

const columns = [
  {
    label: "Id",
    field: "roleId",
    sort: "asc",
    width: 100,
  },
  {
    label: "Role",
    field: "roleName",
    sort: "asc",
    width: 150,
  },
  {
    label: "Status",
    field: "status",
    sort: "asc",
    width: 150,
  },
  {
    label: "Created Date",
    field: "createdDate",
    sort: "asc",
    width: 150,
  },
  {
    label: "Created By",
    field: "createdBy",
    sort: "asc",
    width: 150,
  },
  {
    label: "",
    field: "edit",
    sort: "asc",
    width: 100,
  },
  {
    label: "",
    field: "delete",
    sort: "asc",
    width: 100,
  },
];
const rows = [];

class Role extends Component {
  state = {
    modal: false,
    data: {
      columns,
      rows,
    },
  };
  toggle = () => {
    this.setState({
      modal: !this.state.modal,
    });
  };

  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      usernameError: "",
      passwordError: "",
    };
  }

  handleUsernameChange = (event) => {
    this.setState({
      username: event.target.value,
    });
  };
  handlePasswordChange = (event) => {
    this.setState({
      password: event.target.value,
    });
  };

  validate = () => {
    if (!this.state.username.length > 0) {
      this.setState({
        usernameError: "username is mandatory",
      });
      return false;
    }
    if (!this.state.password.length > 0) {
      this.setState({ passwordError: "password is mandatory" });
      return false;
    }

    return true;
  };

  handleSubmit = (event) => {
    event.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.getRole();
      // clear form
      this.setState({
        username: "",
        password: "",
        usernameError: "",
        passwordError: "",
      });
    }
  };
  async getRole() {
    const url = "/dalrada/user/roleResource/roles/" + this.state.username;
    axios
      .get(url)
      .then((response) => {
        const role = response.data.respBody;
        role.edit = (
          <MDBBtn color="primary" size="sm" className="text-center">
            Edit
          </MDBBtn>
        );
        role.delete = (
          <MDBBtn color="danger" size="sm" className="text-center">
            Delete
          </MDBBtn>
        );
        const rows = [role];
        this.setState({
          data: { columns, rows },
          modal: !this.state.modal,
        });
        console.log(this.state.data);
      })
      .catch((error) => console.log(error));
  }
  async getRoles() {
    axios
      .get("/dalrada/user/roleResource/roles")
      .then((response) => {
        let rows = response.data.map((item) => {
          const role = item.respBody;
          role.edit = (
            <MDBBtn color="primary" size="sm" className="text-center">
              Edit
            </MDBBtn>
          );
          role.delete = (
            <MDBBtn color="danger" size="sm" className="text-center">
              Delete
            </MDBBtn>
          );
          return role;
        });
        this.setState({
          data: { columns, rows },
          modal: !this.state.modal,
        });
      })
      .catch((error) => console.log(error));
  }
  render() {
    return (
      <MDBContainer>
        <div>
          <div>
            <MDBCard>
              <MDBCardHeader
                titleClass="d-inline title"
                color="cyan darken-3"
                type="text"
                className="text-center  darken-3 white-text"
              >
                Create Role
              </MDBCardHeader>
              <MDBCardBody>
                <form onSubmit={this.handleSubmit}>
                  <MDBInput
                    label="Role Name:"
                    className="text-center"
                    type="text"
                    value={this.state.role}
                    onChange={this.handleRoleChange}
                  />
                  <div className="text-center red-text">
                    {this.state.roleError}
                  </div>
                  <div className="text-center mt-1-half">
                    <MDBBtn
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                      type="submit"
                    >
                      Create
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                    <MDBBtn
                      color="primary"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                    >
                      Reset
                    </MDBBtn>
                  </div>
                </form>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="mt-5">
            <MDBCard>
              <MDBCardHeader
                titleClass="d-inline title"
                color="cyan darken-3"
                className="text-center darken-3 white-text"
              >
                Manage Role
              </MDBCardHeader>
              <MDBCardBody>
                <form onSubmit={this.handleSubmit}>
                  <MDBContainer>
                    <MDBRow>
                      <MDBCol md="6">
                        <MDBInput
                          label="User Name"
                          type="text"
                          value={this.state.username}
                          onChange={this.handleUsernameChange}
                          className="text-center"
                        />
                        <div className="text-center red-text">
                          {this.state.usernameError}
                        </div>
                      </MDBCol>
                      <MDBCol md="6">
                        <MDBInput
                          label="Password"
                          type="password"
                          onChange={this.handlePasswordChange}
                          value={this.state.password}
                          className="text-center"
                        />
                        <div className="text-center red-text">
                          {this.state.passwordError}
                        </div>
                      </MDBCol>
                    </MDBRow>
                  </MDBContainer>

                  <div className="text-center mt-1-half">
                    <MDBBtn
                      type="submit"
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                    >
                      Role
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                    <MDBBtn
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                      onClick={this.getRoles.bind(this)}
                    >
                      All Role
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                  </div>
                </form>
              </MDBCardBody>
            </MDBCard>
          </div>
        </div>
        <MDBModal isOpen={this.state.modal} toggle={this.toggle} size="fluid">
          <MDBModalHeader toggle={this.toggle}>Role Details</MDBModalHeader>
          <MDBModalBody>
            <MDBDataTable
              striped
              bordered
              responsive
              paging={false}
              searching={false}
              data={this.state.data}
            />
          </MDBModalBody>
          <MDBModalFooter>
            <MDBBtn
              color="secondary"
              className="mb-2 mt-3 rounded-pill"
              onClick={this.toggle}
              outline
            >
              Close
            </MDBBtn>
          </MDBModalFooter>
        </MDBModal>
      </MDBContainer>
    );
  }
}

export default Role;
