import React, { Component } from "react";

class Temp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: ""
    };
  }
  handleUsernameChange = event => {
    this.setState({
      username: event.target.value
    });
  };

  handleSubmit = event => {
    alert(`${this.state.username}`);
  };
  render() {
    return <div></div>;
  }
}

export default Temp;
