import React, { Component } from "react";
import {
  MDBNavLink,
  MDBListGroup,
  MDBContainer,
  MDBListGroupItem
} from "mdbreact";
import { BrowserRouter as Router } from "react-router-dom";
import { Route, Switch } from "react-router-dom";
import Register from "./register";
import SignIn from "./signIn";
class Link extends Component {
  state = {
    isOpen: false,
    modal: false
  };

  render() {
    return (
      <Router>
        <MDBContainer></MDBContainer>
      </Router>
    );
  }
}

export default Link;
