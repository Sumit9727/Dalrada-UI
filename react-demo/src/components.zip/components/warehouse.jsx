import React, { Component } from "react";
import axios from "axios";
import {
  MDBContainer,
  MDBInput,
  MDBBtn,
  MDBCard,
  MDBCardHeader,
  MDBCardBody,
  MDBIcon,
  MDBModal,
  MDBModalBody,
  MDBModalHeader,
  MDBModalFooter,
  MDBDataTable,
  MDBRow,
  MDBCol,
} from "mdbreact";

const columns = [
  {
    label: "Warehouse Id",
    field: "warehouseId",
    sort: "asc",
    width: 100,
  },
  {
    label: "Name",
    field: "warehouseName",
    sort: "asc",
    width: 150,
  },
  {
    label: "Address",
    field: "warehouseAddress",
    sort: "asc",
    width: 150,
  },
  {
    label: "Code",
    field: "warehouseCode",
    sort: "asc",
    width: 150,
  },
  {
    label: "Status",
    field: "status",
    sort: "asc",
    width: 150,
  },
  {
    label: "Created Date",
    field: "createdDate",
    sort: "asc",
    width: 150,
  },
  {
    label: "Created By",
    field: "createdBy",
    sort: "asc",
    width: 150,
  },
  {
    label: "",
    field: "edit",
    sort: "asc",
    width: 100,
  },
  {
    label: "",
    field: "delete",
    sort: "asc",
    width: 100,
  },
];
const rows = [];

class Warehouse extends Component {
  state = {
    modal: false,
  };
  toggle = () => {
    this.setState({
      modal: !this.state.modal,
    });
  };
  constructor(props) {
    super(props);
    this.state = {
      warehouseCode: "",
      name: "",
      address: "",
      warehouseCodeError: "",
      nameError: "",
      addressError: "",
      data: { columns, rows },
    };
  }
  toggle = () => {
    this.setState({
      modal: !this.state.modal,
    });
  };

  handleNameChange = (event) => {
    this.setState({
      name: event.target.value,
    });
  };
  handleAddressChange = (event) => {
    this.setState({
      address: event.target.value,
    });
  };
  handleWarehouseCodeChange = (event) => {
    this.setState({
      warehouseCode: event.target.value,
    });
  };
  validate = () => {
    if (!this.state.warehouseCode > 0) {
      this.setState({
        warehouseCodeError: "Warehouse Code is mandatory",
      });
      return false;
    }
    return true;
  };

  handleWarehouseSubmit = (event) => {
    event.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      event.preventDefault();
      this.getWarehouse();
      // clear form
      this.setState({
        warehouseCode: "",
      });
    }
  };
  async getWarehouse() {
    const url = "dalrada/warehouse/warehouses/" + this.state.warehouseCode;
    let token = JSON.parse(localStorage.getItem("token"));
    const headers = { Authorization: "Bearer " + token.uuid };
    axios
      .get(url, { headers })
      .then((response) => {
        const warehouse = response.data.respBody;
        warehouse.edit = (
          <MDBBtn color="primary" size="sm" className="text-center">
            Edit
          </MDBBtn>
        );
        warehouse.delete = (
          <MDBBtn color="danger" size="sm" className="text-center">
            Delete
          </MDBBtn>
        );
        const rows = [warehouse];
        this.setState({
          data: { columns, rows },
          modal: !this.state.modal,
        });
      })
      .catch((error) => console.log(error));
  }
  async getWarehouses() {
    const url = "dalrada/warehouse/warehouses";
    let token = JSON.parse(localStorage.getItem("token"));
    const headers = { Authorization: "Bearer " + token.uuid };
    axios
      .get(url, { headers })
      .then((response) => {
        let rows = response.data.map((item) => {
          const warehouse = item.respBody;
          warehouse.edit = (
            <MDBBtn color="primary" size="sm" className="text-center">
              Edit
            </MDBBtn>
          );
          warehouse.delete = (
            <MDBBtn color="danger" size="sm" className="text-center">
              Delete
            </MDBBtn>
          );
          return warehouse;
        });
        this.setState({
          data: { columns, rows },
          modal: !this.state.modal,
        });
        console.log(this.state.data);
      })
      .catch((error) => console.log(error));
  }

  render() {
    return (
      <MDBContainer>
        <div>
          <div>
            <MDBCard>
              <MDBCardHeader
                titleClass="d-inline title"
                color="cyan darken-3"
                type="text"
                className="text-center  darken-3 white-text"
              >
                Create Warehouse
              </MDBCardHeader>
              <MDBCardBody>
                <form onSubmit={this.handleSubmit}>
                  <MDBContainer>
                    <MDBRow>
                      <MDBCol md="6">
                        <MDBInput
                          label="Warehouse Name:"
                          className="text-center"
                          type="text"
                          value={this.state.name}
                          onChange={this.handleNameChange}
                        />
                        <div className="text-center red-text">
                          {this.state.nameError}
                        </div>
                      </MDBCol>
                      <MDBCol md="6">
                        <MDBInput
                          label="Warehouse Code:"
                          value={this.state.warehouseCode}
                          onChange={this.handleWarehouseCodeChange}
                          className="text-center"
                        />
                        <div className="text-center red-text">
                          {this.state.warehouseIdError}
                        </div>
                      </MDBCol>
                    </MDBRow>
                  </MDBContainer>

                  <MDBInput
                    label="Address:"
                    type="text"
                    value={this.state.address}
                    onChange={this.handleAddressChange}
                    className="text-center"
                    iconClass="dark-grey"
                  />
                  <div className="text-center red-text">
                    {this.state.addressError}
                  </div>

                  <div className="text-center mt-1-half">
                    <MDBBtn
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                      type="submit"
                    >
                      Create
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                    <MDBBtn
                      color="primary"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                    >
                      Reset
                    </MDBBtn>
                  </div>
                </form>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="mt-5">
            <MDBCard>
              <MDBCardHeader
                titleClass="d-inline title"
                color="cyan darken-3"
                className="text-center darken-3 white-text"
              >
                Manage Warehouse
              </MDBCardHeader>
              <MDBCardBody>
                <form onSubmit={this.handleWarehouseSubmit}>
                  <MDBInput
                    label="Warehouse Code:"
                    value={this.state.warehouseCode}
                    onChange={this.handleWarehouseCodeChange}
                    className="text-center"
                  />
                  <div className="text-center red-text">
                    {this.state.warehouseIdError}
                  </div>

                  <div className="text-center mt-1-half">
                    <MDBBtn
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                      type="submit"
                    >
                      Warehouse Details
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                    <MDBBtn
                      color="danger"
                      className="mb-2 mt-3 rounded-pill"
                      outline
                      onClick={this.getWarehouses.bind(this)}
                    >
                      All Warehouse
                      <MDBIcon icon="paper-plane" className="ml-1" />
                    </MDBBtn>
                  </div>
                </form>
              </MDBCardBody>
            </MDBCard>
          </div>
        </div>
        <MDBModal isOpen={this.state.modal} toggle={this.toggle} size="fluid">
          <MDBModalHeader toggle={this.toggle}>
            Warehouse Details
          </MDBModalHeader>
          <MDBModalBody>
            <MDBDataTable
              striped
              bordered
              responsive
              paging={false}
              searching={false}
              small
              data={this.state.data}
            />
          </MDBModalBody>
          <MDBModalFooter>
            <MDBBtn
              color="secondary"
              className="mb-2 mt-3 rounded-pill"
              onClick={this.toggle}
              outline
            >
              Close
            </MDBBtn>
          </MDBModalFooter>
        </MDBModal>
      </MDBContainer>
    );
  }
}

export default Warehouse;
